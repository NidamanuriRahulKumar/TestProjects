export class OrderStatus {

  status: string;

  constructor(status: string) {
    this.status = status;
  }
}
