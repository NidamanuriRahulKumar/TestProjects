export class Role {

  name: string;

  constructor(name: string) {
    this.name = name;
  }

}
