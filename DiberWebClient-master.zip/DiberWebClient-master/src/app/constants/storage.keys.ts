export const keys = {
  USER: 'USER',
  TOKEN: 'TOKEN'
};
