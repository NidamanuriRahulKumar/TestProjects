import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeago-pipe-module',
  templateUrl: './timeago-pipe-module.component.html',
  styleUrls: ['./timeago-pipe-module.component.css']
})
export class TimeagoPipeModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
