import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courier-dashboard',
  templateUrl: 'courier-dashboard.component.html',
  styleUrls: ['courier-dashboard.component.css']
})
export class CourierDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
