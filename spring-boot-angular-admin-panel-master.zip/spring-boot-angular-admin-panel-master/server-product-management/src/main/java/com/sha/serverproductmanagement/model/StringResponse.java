package com.sha.serverproductmanagement.model;

import lombok.Data;

@Data
public class StringResponse {
    private String response;
}
