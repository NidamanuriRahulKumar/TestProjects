package com.sha.serverproductmanagement.model;

public enum Role {
    USER, ADMIN
}


