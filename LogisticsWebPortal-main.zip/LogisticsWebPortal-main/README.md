# LogisticsWebPortal
Felhasználók és jelszók a users adatbázist létrehozó és adatokkal feltöltő mappában találhatóak. 
Viszont mivel Hash-elve vannak értelmezhetetlen, de majdnem minden felhasználónak ugyan az a jelszava.
Egy Példa.
Név: Bob1 Jelszó: asd12345
