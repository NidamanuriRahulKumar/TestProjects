import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-selector',
  templateUrl: './app-selector.component.html',
  styleUrls: ['./app-selector.component.css']
})
export class AppSelectorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
