import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-admin-contact',
  templateUrl: './user-admin-contact.component.html',
  styleUrls: ['./user-admin-contact.component.scss']
})
export class UserAdminContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
