//package com.ismail.issuetracking;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class IssueTrackingApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
