package com.pfa.app.model.dto;

public interface EmployeeAssignedProject {
	
	public abstract Integer getEmployeeId();
	// public abstract Integer getProjectId();
	public abstract String getFirstName();
	public abstract String getLastName();
	public abstract Integer getVerif();
	
}









