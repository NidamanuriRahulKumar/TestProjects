package com.pfa.app.model.dto;

public interface ProjectCommitInfoDTO {
	
	public abstract String getUsername();
	public abstract Integer getProjectId();
	public abstract String getTitle();
	
}







