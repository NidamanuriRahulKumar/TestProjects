package com.pfa.app.util.email;

public interface EmailUtil {
	
	public abstract void sendEmail(final String to, final String subject, final String body);
	
}







