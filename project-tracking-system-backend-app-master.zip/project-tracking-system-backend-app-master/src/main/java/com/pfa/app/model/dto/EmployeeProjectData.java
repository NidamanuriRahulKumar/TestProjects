package com.pfa.app.model.dto;

public interface EmployeeProjectData {
	
	public abstract Integer getProjectId();
	public abstract String getTitle();
	public abstract String getStartDate();
	public abstract String getEndDate();
	public abstract String getStatus();
	
}







