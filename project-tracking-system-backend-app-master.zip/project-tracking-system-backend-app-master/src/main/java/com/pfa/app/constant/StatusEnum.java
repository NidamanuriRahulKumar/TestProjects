package com.pfa.app.constant;

public enum StatusEnum {
	
	NOT_STARTED,
	IN_PROGRESS,
	COMPLETED
	
}








