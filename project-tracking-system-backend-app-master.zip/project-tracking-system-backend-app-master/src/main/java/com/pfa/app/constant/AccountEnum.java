package com.pfa.app.constant;

public enum AccountEnum {
	
	EMPLOYEE,
	MANAGER,
	ADMIN
	
}






