package com.pfa.app.model.dto;

public class AssignmentDto {
	
	private String employeeId;
	private String projectId;
	private String commitDate;
	private String commitMgrDesc;
	
	public AssignmentDto() {
		
	}
	
	public String getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getProjectId() {
		return projectId;
	}
	
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	
	public String getCommitDate() {
		return commitDate;
	}
	
	public void setCommitDate(String commitDate) {
		this.commitDate = commitDate;
	}
	
	public String getCommitMgrDesc() {
		return commitMgrDesc;
	}
	
	public void setCommitMgrDesc(String commitMgrDesc) {
		this.commitMgrDesc = commitMgrDesc;
	}
	
	
	
}











