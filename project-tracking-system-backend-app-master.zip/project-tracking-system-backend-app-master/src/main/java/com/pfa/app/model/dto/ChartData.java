package com.pfa.app.model.dto;

public interface ChartData {
	
	public abstract String getLabel();
	public abstract long getValue();
	
}








