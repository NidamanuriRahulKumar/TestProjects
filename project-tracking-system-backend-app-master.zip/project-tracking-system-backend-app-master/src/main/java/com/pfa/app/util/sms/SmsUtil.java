package com.pfa.app.util.sms;

public interface SmsUtil {
	
	public abstract void sendSms(final Sms sms);
	
}









