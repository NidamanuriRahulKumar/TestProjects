package com.pfa.app.model.dto;

public interface ManagerProjectData extends EmployeeProjectData {
	
	
	
}





