
CREATE TABLE departments (
  department_id INT(11) NOT NULL primary key auto_increment,
  department_name VARCHAR(255) DEFAULT NULL,
  location_id INT(11) DEFAULT NULL
);
