
INSERT INTO employees (employee_id, first_name, last_name, email, phone, hiredate, job, salary, manager_id, department_id) VALUES
(1, 'Selim', 'Horri', 'springabcxyzboot@gmail.com', '22125144', '2019-04-15', 'Billing', '5000.00', 4, 6),
(2, 'Badr', 'Idoudi', 'springabcxyzboot@gmail.com', '22125144', '2019-04-15', 'Digital', '5000.00', 9, 5),
(3, 'Imen', 'Touk', 'springabcxyzboot@gmail.com', '22125144', '2019-04-15', 'Data Warehouse', '5000.00', 5, 4),
(4, 'Soumaya', 'Hajjem', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Chef service Billing', '6000.00', NULL, 6),
(5, 'Nour', 'Larguech', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Chef service Data Warehouse', '6000.00', NULL, 4),
(6, 'Khdija', 'Ben Ghachame', 'springabcxyzboot@gmail.com', '22125144', '2559-01-01', 'Billing', '5000.50', 4, 6),
(7, 'Maryem', 'Tlemseni', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Billing', '5000.00', 4, 6),
(8, 'Malek', 'Aissa', 'springabcxyzboot@gmail.com', '22125144', '2020-09-01', 'Billing', '5000.00', 4, 6),
(9, 'John', 'Doe', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Chef service digital', '6000.00', NULL, 5),
(10, 'Sana', 'Saanouni', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Digital', '5000.00', 9, 5),
(11, 'Marwen', 'Mejri', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Digital', '5000.60', 9, 5),
(12, 'Mayssa', 'Hassine', 'springabcxyzboot@gmail.com', '22125144', '2019-04-30', 'Data Warehouse', '5000.00', 5, 4),
(13, 'Mouna', 'Chaouachi', 'springabcxyzboot@gmail.com', '22125144', NULL, 'Data Warehouse', '5000.50', 5, 4),
(14, 'admin', 'admin', 'springabcxyzboot@gmail.com', '22125144', NULL, 'RH', '5000.00', NULL, NULL);
