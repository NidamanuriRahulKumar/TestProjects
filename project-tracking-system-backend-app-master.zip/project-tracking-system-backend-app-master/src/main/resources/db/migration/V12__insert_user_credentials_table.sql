
INSERT INTO user_credentials (user_id, username, password, enabled, role, employee_id) VALUES
(1, 'imentouk', '$2y$04$8jC1Xb/fKB3EQIHy0XoFUunQNhjiVpvuMZys6iCOkphCAsyBkmCTC', 1, 'ROLE_EMP', 3),
(2, 'badridoudi', '$2y$04$c09yvJ4rcadTRGaoVQRRZugld/9z377uaIHwRCWxexBADCVT.jC4S', 1, 'ROLE_EMP', 2),
(3, 'selimhorri', '$2a$10$ldBd/ZuGtUgxHNKd.qCGxuPVVM5oZ6kHkKyu5By8NIQxrv4rV9O/C', 1, 'ROLE_EMP', 1),
(4, 'admin', '$2y$04$HLi44N6cb6xmLYHdABF/euCgpk0LofYk4VdIeO1DAn.Ol1Bnaj3vW', 1, 'ROLE_ADMIN', 14),
(5, 'soumayahajjem', '$2y$04$ljw6KJaAkzMzJZOf8eU6qOoq7jV2SXRqeg7uHS7tQb6x86SBS/oEW', 1, 'ROLE_MGR', 4),
(6, 'nourlarguech', '$2y$04$ngbUBXKPaTRFAUFEifgPpuqmBTf4VjUJL.eGpeEIGwI/iiE18ZSny', 1, 'ROLE_MGR', 5),
(7, 'johndoe', '$2y$04$CT3Jad4jrOq1zGt0Q4maEeTV57rdLtYNVnBM96vyVaGbaE4YgwfvO', 1, 'ROLE_MGR', 9),
(8, 'kbenghachame', '$2y$04$SE6NDj5qAIbCehmTsvU0jeocRrdZTDxDMQ9GapIhD9bnBgtQX.HA.', 1, 'ROLE_EMP', 6),
(9, 'malekaissa', '$2y$04$tajXWCrvBC7ow/rqfmz1i.Z4IPcZdoBa0GMltMFkkzPIiTGguHIgi', 1, 'ROLE_EMP', 8),
(10, 'maryemtlemseni', '$2y$04$PYOfQrM6MgHVY6myHfczsOlNVGXxllW0VD0/LYavV218kXluGm6km', 1, 'ROLE_EMP', 7),
(11, 'sanasaanouni', '$2y$04$BkD79ayx3QMaejraXzbqpOBkI4o051te7mMHu.srQCXavqqKqQLgG', 1, 'ROLE_EMP', 10),
(12, 'marwenmejri', '$2y$04$CNyDXJky.Z3Y1du0tokD6.rioMTQYlRluFekLrsgItPzzRt/hLKSq', 1, 'ROLE_EMP', 11),
(13, 'mayssahassine', '$2y$04$6Rbak.AKdlBl/ir1rNLNteJAbxnEJDoPjH2F2Zd9B2fIVAHbbDTCq', 1, 'ROLE_EMP', 12),
(14, 'mounachaouachi', '$2y$04$EyNVxSrtBJKMG8NqATSv1uhDeZoEOrY4.uk1Ou/4jZABL8kOssJae', 1, 'ROLE_EMP', 13);
