
INSERT INTO locations (location_id, adr, postal_code, city) VALUES
(1, 'RUE DE LA BOURSE', '2016', 'LAC2'),
(2, 'RUE DE BLA BLA', '2016', 'CHARGUIA');
