
INSERT INTO departments (department_id, department_name, location_id) VALUES
(4, 'DWH', 1),
(5, 'Digital', 1),
(6, 'Billing', 1);
