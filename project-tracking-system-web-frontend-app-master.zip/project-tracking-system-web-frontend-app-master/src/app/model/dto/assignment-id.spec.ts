import { AssignmentId } from './assignment-id';

describe('AssignmentId', () => {
  it('should create an instance', () => {
    expect(new AssignmentId()).toBeTruthy();
  });
});
