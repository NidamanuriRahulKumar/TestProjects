import { DtoCollection } from './dto-collection';

describe('DtoCollection', () => {
  it('should create an instance', () => {
    expect(new DtoCollection()).toBeTruthy();
  });
});
