
export class DtoCollection<T> {
    
    constructor(public collection: T[]) {
        
    }
    
}




