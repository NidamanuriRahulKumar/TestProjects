import { AuthenticationRequest } from './authentication-request';

describe('AuthenticationRequest', () => {
  it('should create an instance', () => {
    expect(new AuthenticationRequest()).toBeTruthy();
  });
});
