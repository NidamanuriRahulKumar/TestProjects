export class Credential {
}
