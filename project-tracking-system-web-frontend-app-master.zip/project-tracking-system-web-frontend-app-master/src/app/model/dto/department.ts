export class Department {
}
