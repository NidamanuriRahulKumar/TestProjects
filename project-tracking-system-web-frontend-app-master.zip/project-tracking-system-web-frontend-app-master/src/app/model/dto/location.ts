export class Location {
}
