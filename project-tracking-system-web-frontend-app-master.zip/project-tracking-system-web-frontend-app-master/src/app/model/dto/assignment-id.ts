
export class AssignmentId {
    
    constructor(public employeeId: number,
                public projectId: number,
                public commitDate: Date) {
        
    }
    
    
    
}
