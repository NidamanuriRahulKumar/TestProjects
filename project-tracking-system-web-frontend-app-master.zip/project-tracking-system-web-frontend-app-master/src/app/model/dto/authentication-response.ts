
export class AuthenticationResponse {
    
    constructor(public username: string,
                public isEligible: boolean) {
        
    }
    
    
    
}
