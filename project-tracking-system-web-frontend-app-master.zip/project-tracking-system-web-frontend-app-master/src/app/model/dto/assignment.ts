export class Assignment {
}
